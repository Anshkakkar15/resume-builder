import React from "react";

export const Template2 = () => {
  return <div>template2</div>;
};
