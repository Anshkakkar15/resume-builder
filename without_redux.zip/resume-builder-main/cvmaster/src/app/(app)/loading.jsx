import { PageLoader } from "@/components/loaders/PageLoader";

export default function loading() {
  return <PageLoader />;
}
