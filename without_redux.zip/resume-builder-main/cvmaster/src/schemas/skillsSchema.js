import * as yup from "yup";

export const summarySchema = yup.object().shape({
  summary: yup.string().required("Field is required"),
});
