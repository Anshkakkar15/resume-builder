export const timeline = [
  {
    id: 1,
    title: "Introduction",
  },
  {
    id: 2,
    title: "Language",
  },
  {
    id: 3,
    title: "Experience",
  },
  {
    id: 4,
    title: "Education",
  },
  {
    id: 5,
    title: "Skills",
  },
  {
    id: 6,
    title: "Summary",
  },
];
